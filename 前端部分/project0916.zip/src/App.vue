<template>
  <div id="app">
    <router-view />
    <!-- <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>-->
  </div>
</template>

<style lang="scss">
#app {
  height: 100vh; //vh屏幕高度，100vh，100屏幕高度
}
</style>
